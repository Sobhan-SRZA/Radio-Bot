/**
 *
 * @param {string} string
 * @returns {string}
 */
module.exports = function (string) {
  return `${string[0].toUpperCase()}${string.slice(1).toLowerCase()}`;
}
/**
 * @copyright
 * Coded by Sobhan-SRZA (mr.sinre) | https://github.com/Sobhan-SRZA
 * @copyright
 * Work for Persian Caesar | https://dsc.gg/persian-caesar
 * @copyright
 * Please Mention Us "Persian Caesar", When Have Problem With Using This Code!
 * @copyright
 */
